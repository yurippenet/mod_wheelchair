<?php 
// No direct access
defined('_JEXEC') or die; 
 
echo "START";

print_r($technicalData); 

echo "END";
?>