<?php
/**
 * Helper class for Wheelchair module
 * 
 * @package    Atom-it.dk
 * @subpackage Modules
 * @link 	   http://atom-it.dk
 * @license    
 */
class modWheelchairHelper
{

    public static function getHello($params)
    {
        return 'Hello, World!';
    }
}